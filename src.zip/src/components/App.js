import React, {Component, useState} from "react";
import '../styles/App.css';

const App = () => {
  return (
    <div id="main"></div>
  )
}


export default App;

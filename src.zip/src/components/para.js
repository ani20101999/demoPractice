import React from "react";

function Para(){
    return <p>"I am learning React. My life is getting better."</p>
}

export default Para
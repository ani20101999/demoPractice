import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";
import Para from "./components/para";


ReactDOM.render(
    <>
    <div>
        <Para />
    </div>
    </>

, document.getElementById("root")
);